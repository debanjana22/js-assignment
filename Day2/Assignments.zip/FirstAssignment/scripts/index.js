var name = prompt('Please enter name');
console.log(`Your name is ${name}`);