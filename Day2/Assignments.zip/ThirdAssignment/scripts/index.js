var isOfDrinkableAge = confirm('Is your age more than 21?');
if (isOfDrinkableAge === true){
    console.log("Can drink");
}
else {
    console.log("Cannot drink");
}