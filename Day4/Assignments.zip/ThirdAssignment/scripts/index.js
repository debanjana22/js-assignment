let shoppingList = ["Apples", "Flour", "Onions", "Salt"];
let shoppingBasket = [...shoppingList];
shoppingBasket.push("Eggs");
shoppingBasket.push("Bread");

console.log(`Shopping List: ${shoppingList}`);
console.log(`Shopping Basket: ${shoppingBasket}`);